export interface TradingSignal {
  id: string;
  symbol: string;
  action: 'BUY' | 'SELL';
  entry_price: number;
  take_profit: number;
  stop_loss: number;
  confidence: number;
  reasoning: string;
  timestamp: Date;
  strategy_used: string;
  risk_reward_ratio: number;
  timeframe: string;
  status: 'ACTIVE' | 'COMPLETED' | 'STOPPED';
}

export interface MarketData {
  symbol: string;
  price: number;
  change: number;
  change_percent: number;
  volume: number;
  high_24h: number;
  low_24h: number;
  market_cap?: number;
  last_updated: Date;
}

export interface TechnicalIndicators {
  rsi: number;
  macd: {
    macd: number;
    signal: number;
    histogram: number;
  };
  bollinger_bands: {
    upper: number;
    middle: number;
    lower: number;
  };
  moving_averages: {
    ma5: number;
    ma10: number;
    ma20: number;
    ma50: number;
  };
  support_resistance: {
    support: number[];
    resistance: number[];
  };
}

export interface WatchlistItem {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change: number;
  change_percent: number;
  alert_price?: number;
  created_at: Date;
}

export interface UserPreferences {
  theme: 'dark' | 'light';
  notifications_enabled: boolean;
  risk_tolerance: 'low' | 'medium' | 'high';
  preferred_timeframes: string[];
  max_signals_per_day: number;
  auto_trading: boolean;
}

export interface AIAnalysis {
  market_sentiment: 'bullish' | 'bearish' | 'neutral';
  confidence_score: number;
  key_factors: string[];
  risk_assessment: string;
  recommended_action: string;
  time_horizon: string;
}