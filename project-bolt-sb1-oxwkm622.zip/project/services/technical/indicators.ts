export class TechnicalIndicators {
  static calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period + 1) return 50;

    const gains: number[] = [];
    const losses: number[] = [];

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      gains.push(change > 0 ? change : 0);
      losses.push(change < 0 ? Math.abs(change) : 0);
    }

    const avgGain = gains.slice(-period).reduce((sum, gain) => sum + gain, 0) / period;
    const avgLoss = losses.slice(-period).reduce((sum, loss) => sum + loss, 0) / period;

    if (avgLoss === 0) return 100;
    
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  static calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9): any {
    if (prices.length < slowPeriod) {
      return { macd: 0, signal: 0, histogram: 0 };
    }

    const emaFast = this.calculateEMA(prices, fastPeriod);
    const emaSlow = this.calculateEMA(prices, slowPeriod);
    
    const macdLine = emaFast - emaSlow;
    const macdHistory = [];
    
    // Calculate MACD for signal line
    for (let i = slowPeriod - 1; i < prices.length; i++) {
      const fastEMA = this.calculateEMA(prices.slice(0, i + 1), fastPeriod);
      const slowEMA = this.calculateEMA(prices.slice(0, i + 1), slowPeriod);
      macdHistory.push(fastEMA - slowEMA);
    }
    
    const signal = this.calculateEMA(macdHistory, signalPeriod);
    const histogram = macdLine - signal;

    return {
      macd: macdLine,
      signal: signal,
      histogram: histogram
    };
  }

  static calculateBollingerBands(prices: number[], period: number = 20, multiplier: number = 2): any {
    if (prices.length < period) {
      const lastPrice = prices[prices.length - 1] || 0;
      return {
        upper: lastPrice * 1.02,
        middle: lastPrice,
        lower: lastPrice * 0.98
      };
    }

    const sma = this.calculateSMA(prices, period);
    const recentPrices = prices.slice(-period);
    
    const variance = recentPrices.reduce((sum, price) => {
      return sum + Math.pow(price - sma, 2);
    }, 0) / period;
    
    const standardDeviation = Math.sqrt(variance);

    return {
      upper: sma + (standardDeviation * multiplier),
      middle: sma,
      lower: sma - (standardDeviation * multiplier)
    };
  }

  static calculateMovingAverages(prices: number[]): any {
    return {
      ma5: this.calculateSMA(prices, 5),
      ma10: this.calculateSMA(prices, 10),
      ma20: this.calculateSMA(prices, 20),
      ma50: this.calculateSMA(prices, 50)
    };
  }

  static calculateSMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1] || 0;
    
    const recentPrices = prices.slice(-period);
    return recentPrices.reduce((sum, price) => sum + price, 0) / period;
  }

  static calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0;
    if (prices.length < period) return prices[prices.length - 1];

    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }

    return ema;
  }

  static findSupportResistance(prices: number[], periods: number = 20): any {
    if (prices.length < periods * 2) {
      return { support: [], resistance: [] };
    }

    const peaks: number[] = [];
    const troughs: number[] = [];

    for (let i = periods; i < prices.length - periods; i++) {
      const window = prices.slice(i - periods, i + periods + 1);
      const currentPrice = prices[i];
      
      const isHighest = window.every(price => price <= currentPrice);
      const isLowest = window.every(price => price >= currentPrice);
      
      if (isHighest) peaks.push(currentPrice);
      if (isLowest) troughs.push(currentPrice);
    }

    return {
      support: troughs.slice(-3),
      resistance: peaks.slice(-3)
    };
  }

  static calculateAllIndicators(prices: number[]): any {
    return {
      rsi: this.calculateRSI(prices),
      macd: this.calculateMACD(prices),
      bollinger_bands: this.calculateBollingerBands(prices),
      moving_averages: this.calculateMovingAverages(prices),
      support_resistance: this.findSupportResistance(prices)
    };
  }
}