import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { TradingSignal } from '../../types/trading';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export class PushNotificationService {
  static async requestPermissions(): Promise<boolean> {
    try {
      if (Platform.OS === 'web') {
        return true; // Skip permissions on web
      }

      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      return finalStatus === 'granted';
    } catch (error) {
      console.error('Error requesting notification permissions:', error);
      return false;
    }
  }

  static async sendTradingSignalNotification(signal: TradingSignal): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        // Web notification fallback
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(`${signal.action} Signal: ${signal.symbol}`, {
            body: `Entry: $${signal.entry_price.toFixed(2)} | Confidence: ${Math.round(signal.confidence * 100)}%`,
            icon: '/assets/images/icon.png',
          });
        }
        return;
      }

      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        console.warn('Notification permission not granted');
        return;
      }

      const profitColor = signal.action === 'BUY' ? '#10B981' : '#EF4444';
      
      await Notifications.scheduleNotificationAsync({
        content: {
          title: `🚀 ${signal.action} Signal: ${signal.symbol}`,
          body: `Entry: $${signal.entry_price.toFixed(2)} | TP: $${signal.take_profit.toFixed(2)} | SL: $${signal.stop_loss.toFixed(2)}`,
          subtitle: `${Math.round(signal.confidence * 100)}% Confidence | ${signal.strategy_used}`,
          sound: 'default',
          color: profitColor,
          data: {
            type: 'trading_signal',
            signal: signal,
          },
        },
        trigger: null, // Send immediately
      });
    } catch (error) {
      console.error('Error sending trading signal notification:', error);
    }
  }

  static async sendPriceAlert(symbol: string, currentPrice: number, targetPrice: number): Promise<void> {
    try {
      if (Platform.OS === 'web') {
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(`Price Alert: ${symbol}`, {
            body: `Current price: $${currentPrice.toFixed(2)} | Target: $${targetPrice.toFixed(2)}`,
            icon: '/assets/images/icon.png',
          });
        }
        return;
      }

      const hasPermission = await this.requestPermissions();
      if (!hasPermission) return;

      await Notifications.scheduleNotificationAsync({
        content: {
          title: `📈 Price Alert: ${symbol}`,
          body: `Current price: $${currentPrice.toFixed(2)} reached your target of $${targetPrice.toFixed(2)}`,
          sound: 'default',
          data: {
            type: 'price_alert',
            symbol,
            currentPrice,
            targetPrice,
          },
        },
        trigger: null,
      });
    } catch (error) {
      console.error('Error sending price alert:', error);
    }
  }

  static async setupNotificationCategories(): Promise<void> {
    try {
      if (Platform.OS === 'web') return;

      await Notifications.setNotificationCategoryAsync('trading_signal', [
        {
          identifier: 'view_signal',
          buttonTitle: 'View Signal',
          options: {
            opensAppToForeground: true,
          },
        },
        {
          identifier: 'dismiss',
          buttonTitle: 'Dismiss',
          options: {
            opensAppToForeground: false,
          },
        },
      ]);
    } catch (error) {
      console.error('Error setting up notification categories:', error);
    }
  }
}