import { OpenAIService } from '../ai/openai';
import { GeminiService } from '../ai/gemini';
import { GroqService } from '../ai/groq';
import { TechnicalIndicators } from '../technical/indicators';
import { TradingSignal } from '../../types/trading';

export class SignalGenerator {
  private openAI: OpenAIService;
  private gemini: GeminiService;
  private groq: GroqService;

  constructor() {
    this.openAI = new OpenAIService();
    this.gemini = new GeminiService();
    this.groq = new GroqService();
  }

  async generateComprehensiveSignal(
    symbol: string,
    marketData: any,
    newsData: string[] = []
  ): Promise<TradingSignal | null> {
    try {
      const prices = marketData.historical?.map((item: any) => item.close) || [marketData.price];
      const indicators = TechnicalIndicators.calculateAllIndicators(prices);

      // Get signals from all AI providers
      const [openAISignal, groqSignal, sentimentAnalysis] = await Promise.allSettled([
        this.openAI.generateTradingSignal(symbol, marketData, indicators),
        this.groq.generateScalpingSignal(symbol, marketData, indicators),
        this.gemini.analyzeMarketSentiment(symbol, newsData, marketData)
      ]);

      // Combine signals and create consensus
      const signals = [];
      
      if (openAISignal.status === 'fulfilled' && openAISignal.value) {
        signals.push(openAISignal.value);
      }
      
      if (groqSignal.status === 'fulfilled' && groqSignal.value?.signal !== 'HOLD') {
        signals.push({
          ...groqSignal.value,
          action: groqSignal.value.signal,
          strategy_used: 'AI-Groq-Scalping'
        });
      }

      // Apply technical analysis rules
      const technicalSignal = this.generateTechnicalSignal(symbol, prices, indicators, marketData.price);
      if (technicalSignal) {
        signals.push(technicalSignal);
      }

      // If no signals generated, return null
      if (signals.length === 0) {
        return null;
      }

      // Find consensus signal
      const buySignals = signals.filter(s => s.action === 'BUY');
      const sellSignals = signals.filter(s => s.action === 'SELL');

      let finalAction: 'BUY' | 'SELL';
      let consensusSignals: any[];

      if (buySignals.length > sellSignals.length) {
        finalAction = 'BUY';
        consensusSignals = buySignals;
      } else if (sellSignals.length > buySignals.length) {
        finalAction = 'SELL';
        consensusSignals = sellSignals;
      } else {
        // No consensus, return the highest confidence signal
        const highestConfidence = signals.reduce((prev, current) => 
          prev.confidence > current.confidence ? prev : current
        );
        return highestConfidence;
      }

      // Calculate average values for consensus
      const avgConfidence = consensusSignals.reduce((sum, signal) => sum + signal.confidence, 0) / consensusSignals.length;
      const avgStopLoss = consensusSignals.reduce((sum, signal) => sum + signal.stop_loss, 0) / consensusSignals.length;
      const avgTakeProfit = consensusSignals.reduce((sum, signal) => sum + signal.take_profit, 0) / consensusSignals.length;

      // Include sentiment in reasoning
      let sentimentText = '';
      if (sentimentAnalysis.status === 'fulfilled') {
        const sentiment = sentimentAnalysis.value;
        sentimentText = ` Market sentiment: ${sentiment.sentiment} (${Math.round(sentiment.confidence * 100)}% confidence).`;
      }

      return {
        id: `signal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        symbol,
        action: finalAction,
        entry_price: marketData.price,
        take_profit: avgTakeProfit,
        stop_loss: avgStopLoss,
        confidence: avgConfidence,
        reasoning: `Consensus signal from ${consensusSignals.length} AI models. ${consensusSignals[0]?.reasoning || ''}.${sentimentText}`,
        strategy_used: 'AI-Consensus',
        risk_reward_ratio: Math.abs((avgTakeProfit - marketData.price) / (marketData.price - avgStopLoss)),
        timeframe: '15m',
        timestamp: new Date(),
        status: 'ACTIVE'
      };

    } catch (error) {
      console.error('Error generating comprehensive signal:', error);
      return null;
    }
  }

  private generateTechnicalSignal(
    symbol: string,
    prices: number[],
    indicators: any,
    currentPrice: number
  ): TradingSignal | null {
    try {
      const { rsi, macd, bollinger_bands, moving_averages } = indicators;
      let action: 'BUY' | 'SELL' | null = null;
      let confidence = 0;
      let reasoning = '';

      // RSI signals
      if (rsi < 30) {
        action = 'BUY';
        confidence += 0.3;
        reasoning += 'RSI oversold. ';
      } else if (rsi > 70) {
        action = 'SELL';
        confidence += 0.3;
        reasoning += 'RSI overbought. ';
      }

      // MACD signals
      if (macd.macd > macd.signal && macd.histogram > 0) {
        if (action === 'BUY' || action === null) {
          action = 'BUY';
          confidence += 0.25;
          reasoning += 'MACD bullish crossover. ';
        }
      } else if (macd.macd < macd.signal && macd.histogram < 0) {
        if (action === 'SELL' || action === null) {
          action = 'SELL';
          confidence += 0.25;
          reasoning += 'MACD bearish crossover. ';
        }
      }

      // Bollinger Bands signals
      if (currentPrice <= bollinger_bands.lower) {
        if (action === 'BUY' || action === null) {
          action = 'BUY';
          confidence += 0.2;
          reasoning += 'Price at lower Bollinger Band. ';
        }
      } else if (currentPrice >= bollinger_bands.upper) {
        if (action === 'SELL' || action === null) {
          action = 'SELL';
          confidence += 0.2;
          reasoning += 'Price at upper Bollinger Band. ';
        }
      }

      // Moving average signals
      if (moving_averages.ma5 > moving_averages.ma20 && currentPrice > moving_averages.ma5) {
        if (action === 'BUY' || action === null) {
          action = 'BUY';
          confidence += 0.25;
          reasoning += 'Bullish MA crossover. ';
        }
      } else if (moving_averages.ma5 < moving_averages.ma20 && currentPrice < moving_averages.ma5) {
        if (action === 'SELL' || action === null) {
          action = 'SELL';
          confidence += 0.25;
          reasoning += 'Bearish MA crossover. ';
        }
      }

      // Minimum confidence threshold
      if (!action || confidence < 0.5) {
        return null;
      }

      // Calculate stop loss and take profit
      const volatility = this.calculateVolatility(prices);
      let stopLoss, takeProfit;

      if (action === 'BUY') {
        stopLoss = currentPrice * (1 - volatility * 0.75);
        takeProfit = currentPrice * (1 + volatility * 2);
      } else {
        stopLoss = currentPrice * (1 + volatility * 0.75);
        takeProfit = currentPrice * (1 - volatility * 2);
      }

      return {
        id: `tech_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        symbol,
        action,
        entry_price: currentPrice,
        take_profit: takeProfit,
        stop_loss: stopLoss,
        confidence: Math.min(confidence, 0.95),
        reasoning: reasoning.trim(),
        strategy_used: 'Technical-Analysis',
        risk_reward_ratio: Math.abs((takeProfit - currentPrice) / (currentPrice - stopLoss)),
        timeframe: '15m',
        timestamp: new Date(),
        status: 'ACTIVE'
      };

    } catch (error) {
      console.error('Error generating technical signal:', error);
      return null;
    }
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0.02;
    
    const returns = [];
    for (let i = 1; i < prices.length; i++) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
    
    const mean = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - mean, 2), 0) / returns.length;
    
    return Math.sqrt(variance);
  }
}