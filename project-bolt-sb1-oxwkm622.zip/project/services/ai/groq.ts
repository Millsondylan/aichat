interface GroqResponse {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  reasoning: string;
  entry_price: number;
  stop_loss: number;
  take_profit: number;
}

export class GroqService {
  private apiKey: string;
  private baseUrl = 'https://api.groq.com/openai/v1';

  constructor() {
    this.apiKey = process.env.EXPO_PUBLIC_GROQ_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Groq API key not found. Groq features will be disabled.');
    }
  }

  async generateScalpingSignal(
    symbol: string,
    realtimeData: any,
    indicators: any
  ): Promise<GroqResponse> {
    if (!this.apiKey) {
      throw new Error('Groq API key not configured');
    }
    
    try {
      const prompt = `You are an expert scalping trader. Analyze the real-time data for ${symbol} and generate a scalping signal.

Current data:
- Price: ${realtimeData.price}
- Volume: ${realtimeData.volume}
- RSI: ${indicators.rsi}
- MACD: ${JSON.stringify(indicators.macd)}
- Moving Averages: ${JSON.stringify(indicators.moving_averages)}

Generate a scalping signal as JSON with: signal (BUY/SELL/HOLD), confidence (0-1), reasoning, entry_price, stop_loss, take_profit.

For scalping, use tight stop losses (0.5-1% risk) and quick profits (1-2% targets).`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama3-8b-8192',
          messages: [
            {
              role: 'system',
              content: 'You are a professional scalping trader with expertise in high-frequency trading strategies.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 400,
          temperature: 0.1,
        }),
      });

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message);
      }

      const content = data.choices[0].message.content;
      
      try {
        return JSON.parse(content);
      } catch {
        // Fallback parsing
        return {
          signal: 'HOLD',
          confidence: 0.5,
          reasoning: content,
          entry_price: realtimeData.price,
          stop_loss: realtimeData.price * 0.995,
          take_profit: realtimeData.price * 1.015
        };
      }
    } catch (error) {
      console.error('Groq API error:', error);
      throw error;
    }
  }

  async analyzeTechnicalPattern(
    symbol: string,
    priceData: number[],
    pattern: string
  ): Promise<any> {
    if (!this.apiKey) {
      throw new Error('Groq API key not configured');
    }
    
    try {
      const prompt = `Analyze the ${pattern} pattern for ${symbol}.
      
      Price data: ${priceData.slice(-30).join(', ')}
      
      Determine if this pattern is forming and provide trading recommendations as JSON.`;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama3-8b-8192',
          messages: [
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 300,
          temperature: 0.1,
        }),
      });

      const data = await response.json();
      const content = data.choices[0].message.content;
      
      try {
        return JSON.parse(content);
      } catch {
        return { analysis: content, pattern_confirmed: false };
      }
    } catch (error) {
      console.error('Groq pattern analysis error:', error);
      throw error;
    }
  }
}