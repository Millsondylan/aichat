interface GeminiResponse {
  analysis: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
}

export class GeminiService {
  private apiKey: string;
  private baseUrl = 'https://generativelanguage.googleapis.com/v1beta';

  constructor() {
    this.apiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Gemini API key not found. Gemini features will be disabled.');
    }
  }

  async analyzeMarketSentiment(
    symbol: string,
    newsData: string[],
    marketData: any
  ): Promise<GeminiResponse> {
    if (!this.apiKey) {
      throw new Error('Gemini API key not configured');
    }
    
    try {
      const prompt = `Analyze the market sentiment for ${symbol} based on the following data:
      
      Recent news: ${newsData.join('. ')}
      Current price: ${marketData.current_price}
      24h change: ${marketData.change_24h}%
      Volume: ${marketData.volume}
      
      Provide sentiment analysis as JSON with: analysis (string), sentiment (bullish/bearish/neutral), confidence (0-1)`;

      const response = await fetch(
        `${this.baseUrl}/models/gemini-pro:generateContent?key=${this.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: prompt
              }]
            }],
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 500,
            },
          }),
        }
      );

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message);
      }

      const content = data.candidates[0].content.parts[0].text;
      
      try {
        return JSON.parse(content);
      } catch {
        return {
          analysis: content,
          sentiment: 'neutral',
          confidence: 0.5
        };
      }
    } catch (error) {
      console.error('Gemini API error:', error);
      throw error;
    }
  }

  async predictPriceMovement(
    symbol: string,
    historicalData: number[],
    timeframe: string
  ): Promise<any> {
    if (!this.apiKey) {
      throw new Error('Gemini API key not configured');
    }
    
    try {
      const prompt = `As a financial AI expert, predict the price movement for ${symbol} over the ${timeframe} timeframe.
      
      Historical prices (last 50 periods): ${historicalData.slice(-50).join(', ')}
      
      Provide prediction as JSON with: predicted_direction (up/down/sideways), confidence (0-1), target_price (number), reasoning (string)`;

      const response = await fetch(
        `${this.baseUrl}/models/gemini-pro:generateContent?key=${this.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: prompt
              }]
            }],
            generationConfig: {
              temperature: 0.2,
              maxOutputTokens: 400,
            },
          }),
        }
      );

      const data = await response.json();
      const content = data.candidates[0].content.parts[0].text;
      
      try {
        return JSON.parse(content);
      } catch {
        return {
          predicted_direction: 'sideways',
          confidence: 0.5,
          target_price: historicalData[historicalData.length - 1],
          reasoning: content
        };
      }
    } catch (error) {
      console.error('Gemini prediction error:', error);
      throw error;
    }
  }
}