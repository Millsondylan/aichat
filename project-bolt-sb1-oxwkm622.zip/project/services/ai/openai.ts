interface OpenAIResponse {
  analysis: string;
  confidence: number;
  recommendation: 'BUY' | 'SELL' | 'HOLD';
}

export class OpenAIService {
  private apiKey: string;
  private baseUrl = 'https://api.openai.com/v1';

  constructor() {
    this.apiKey = process.env.EXPO_PUBLIC_OPENAI_API_KEY || '';
    if (!this.apiKey) {
      console.warn('OpenAI API key not found. OpenAI features will be disabled.');
    }
  }

  async analyzeMarketData(
    symbol: string,
    priceData: number[],
    indicators: any
  ): Promise<OpenAIResponse> {
    if (!this.apiKey) {
      throw new Error('OpenAI API key not configured');
    }
    
    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are an expert financial trader and analyst. Analyze the provided market data and technical indicators for ${symbol} and provide a trading recommendation. Format your response as JSON with analysis, confidence (0-1), and recommendation (BUY/SELL/HOLD).`
            },
            {
              role: 'user',
              content: `Analyze this data for ${symbol}:
              Recent prices: ${priceData.slice(-20).join(', ')}
              RSI: ${indicators.rsi}
              MACD: ${JSON.stringify(indicators.macd)}
              Bollinger Bands: ${JSON.stringify(indicators.bollinger_bands)}
              Moving Averages: ${JSON.stringify(indicators.moving_averages)}`
            }
          ],
          max_tokens: 500,
          temperature: 0.1,
        }),
      });

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message);
      }

      const content = data.choices[0].message.content;
      
      try {
        return JSON.parse(content);
      } catch {
        // Fallback if response isn't JSON
        return {
          analysis: content,
          confidence: 0.5,
          recommendation: 'HOLD'
        };
      }
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw error;
    }
  }

  async generateTradingSignal(
    symbol: string,
    marketData: any,
    indicators: any
  ): Promise<any> {
    if (!this.apiKey) {
      throw new Error('OpenAI API key not configured');
    }
    
    try {
      const analysis = await this.analyzeMarketData(symbol, marketData.prices, indicators);
      
      const currentPrice = marketData.prices[marketData.prices.length - 1];
      const volatility = this.calculateVolatility(marketData.prices);
      
      let stopLoss, takeProfit;
      
      if (analysis.recommendation === 'BUY') {
        stopLoss = currentPrice * (1 - volatility * 0.5);
        takeProfit = currentPrice * (1 + volatility * 1.5);
      } else if (analysis.recommendation === 'SELL') {
        stopLoss = currentPrice * (1 + volatility * 0.5);
        takeProfit = currentPrice * (1 - volatility * 1.5);
      } else {
        return null; // No signal for HOLD
      }

      return {
        symbol,
        action: analysis.recommendation,
        entry_price: currentPrice,
        take_profit: takeProfit,
        stop_loss: stopLoss,
        confidence: analysis.confidence,
        reasoning: analysis.analysis,
        strategy_used: 'AI-OpenAI',
        risk_reward_ratio: Math.abs((takeProfit - currentPrice) / (currentPrice - stopLoss)),
        timeframe: '15m',
        timestamp: new Date(),
        status: 'ACTIVE'
      };
    } catch (error) {
      console.error('Error generating trading signal:', error);
      throw error;
    }
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0.02;
    
    const returns = [];
    for (let i = 1; i < prices.length; i++) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
    
    const mean = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - mean, 2), 0) / returns.length;
    
    return Math.sqrt(variance);
  }
}