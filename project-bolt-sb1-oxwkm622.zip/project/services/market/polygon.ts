export class PolygonService {
  private apiKey: string;
  private baseUrl = 'https://api.polygon.io';

  constructor() {
    this.apiKey = process.env.EXPO_PUBLIC_POLYGON_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Polygon API key not found. Polygon features will be disabled.');
    }
  }

  async getRealTimePrice(symbol: string): Promise<any> {
    if (!this.apiKey) {
      throw new Error('Polygon API key not configured');
    }
    
    try {
      const response = await fetch(
        `${this.baseUrl}/v2/last/trade/${symbol}?apikey=${this.apiKey}`
      );
      const data = await response.json();
      
      if (data.status === 'OK') {
        return {
          symbol,
          price: data.results.p,
          volume: data.results.s,
          timestamp: new Date(data.results.t),
        };
      }
      
      throw new Error(data.error || 'Failed to fetch price data');
    } catch (error) {
      console.error('Polygon API error:', error);
      throw error;
    }
  }

  async getHistoricalData(
    symbol: string,
    timespan: string,
    from: string,
    to: string
  ): Promise<any> {
    if (!this.apiKey) {
      throw new Error('Polygon API key not configured');
    }
    
    try {
      const response = await fetch(
        `${this.baseUrl}/v2/aggs/ticker/${symbol}/range/1/${timespan}/${from}/${to}?adjusted=true&sort=asc&limit=1000&apikey=${this.apiKey}`
      );
      const data = await response.json();
      
      if (data.status === 'OK') {
        return data.results.map((bar: any) => ({
          timestamp: new Date(bar.t),
          open: bar.o,
          high: bar.h,
          low: bar.l,
          close: bar.c,
          volume: bar.v,
        }));
      }
      
      throw new Error(data.error || 'Failed to fetch historical data');
    } catch (error) {
      console.error('Polygon historical data error:', error);
      throw error;
    }
  }

  async getMarketNews(symbol?: string): Promise<any[]> {
    if (!this.apiKey) {
      console.warn('Polygon API key not configured, returning empty news array');
      return [];
    }
    
    try {
      const url = symbol 
        ? `${this.baseUrl}/v2/reference/news?ticker=${symbol}&order=desc&limit=10&apikey=${this.apiKey}`
        : `${this.baseUrl}/v2/reference/news?order=desc&limit=10&apikey=${this.apiKey}`;
        
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.status === 'OK') {
        return data.results.map((article: any) => ({
          id: article.id,
          title: article.title,
          description: article.description,
          url: article.article_url,
          image_url: article.image_url,
          published_utc: new Date(article.published_utc),
          publisher: article.publisher.name,
          tickers: article.tickers || [],
        }));
      }
      
      return [];
    } catch (error) {
      console.error('Polygon news error:', error);
      return [];
    }
  }

  async getTopGainers(): Promise<any[]> {
    if (!this.apiKey) {
      console.warn('Polygon API key not configured, returning empty gainers array');
      return [];
    }
    
    try {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const dateStr = yesterday.toISOString().split('T')[0];
      
      const response = await fetch(
        `${this.baseUrl}/v2/snapshot/locale/us/markets/stocks/gainers?apikey=${this.apiKey}`
      );
      const data = await response.json();
      
      if (data.status === 'OK') {
        return data.tickers.slice(0, 10).map((ticker: any) => ({
          symbol: ticker.ticker,
          price: ticker.lastQuote?.p || ticker.prevDay?.c,
          change: ticker.todaysChangePerc || 0,
          volume: ticker.day?.v || 0,
        }));
      }
      
      return [];
    } catch (error) {
      console.error('Polygon gainers error:', error);
      return [];
    }
  }
}