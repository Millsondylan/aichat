export class YahooFinanceService {
  private baseUrl = 'https://query1.finance.yahoo.com/v8/finance/chart';

  async getQuote(symbol: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/${symbol}`);
      const data = await response.json();
      
      if (data.chart.error) {
        throw new Error(data.chart.error.description);
      }

      const result = data.chart.result[0];
      const meta = result.meta;
      const quote = result.indicators.quote[0];
      
      return {
        symbol: meta.symbol,
        price: meta.regularMarketPrice,
        change: meta.regularMarketPrice - meta.previousClose,
        change_percent: ((meta.regularMarketPrice - meta.previousClose) / meta.previousClose) * 100,
        volume: meta.regularMarketVolume,
        high_24h: meta.regularMarketDayHigh,
        low_24h: meta.regularMarketDayLow,
        market_cap: meta.marketCap,
        last_updated: new Date(),
      };
    } catch (error) {
      console.error('Yahoo Finance API error:', error);
      throw error;
    }
  }

  async getHistoricalData(symbol: string, range: string = '1mo'): Promise<any[]> {
    try {
      const response = await fetch(
        `${this.baseUrl}/${symbol}?range=${range}&interval=1d`
      );
      const data = await response.json();
      
      const result = data.chart.result[0];
      const timestamps = result.timestamp;
      const quotes = result.indicators.quote[0];
      
      return timestamps.map((timestamp: number, index: number) => ({
        timestamp: new Date(timestamp * 1000),
        open: quotes.open[index],
        high: quotes.high[index],
        low: quotes.low[index],
        close: quotes.close[index],
        volume: quotes.volume[index],
      })).filter((item: any) => item.close !== null);
    } catch (error) {
      console.error('Yahoo Finance historical data error:', error);
      throw error;
    }
  }

  async searchSymbols(query: string): Promise<any[]> {
    try {
      const response = await fetch(
        `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&lang=en-US&region=US&quotesCount=10&newsCount=0`
      );
      const data = await response.json();
      
      return data.quotes.map((quote: any) => ({
        symbol: quote.symbol,
        name: quote.longname || quote.shortname,
        type: quote.quoteType,
        exchange: quote.exchDisp,
      }));
    } catch (error) {
      console.error('Yahoo Finance search error:', error);
      return [];
    }
  }
}