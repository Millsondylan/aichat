import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Bell, TrendingUp, TrendingDown, Settings, Volume2, VolumeX } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius, FontSizes } from '@/constants/colors';
import { PushNotificationService } from '@/services/notifications/pushNotifications';

interface AlertItem {
  id: string;
  type: 'price' | 'signal' | 'news';
  title: string;
  description: string;
  timestamp: Date;
  isRead: boolean;
  action?: 'BUY' | 'SELL';
  symbol?: string;
}

export default function AlertsScreen() {
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [signalAlertsEnabled, setSignalAlertsEnabled] = useState(true);
  const [priceAlertsEnabled, setPriceAlertsEnabled] = useState(true);

  useEffect(() => {
    loadMockAlerts();
    checkNotificationPermissions();
  }, []);

  const checkNotificationPermissions = async () => {
    const hasPermission = await PushNotificationService.requestPermissions();
    setNotificationsEnabled(hasPermission);
  };

  const loadMockAlerts = () => {
    const mockAlerts: AlertItem[] = [
      {
        id: '1',
        type: 'signal',
        title: 'BUY Signal: AAPL',
        description: 'AI generated BUY signal with 85% confidence. Entry: $150.25',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        isRead: false,
        action: 'BUY',
        symbol: 'AAPL',
      },
      {
        id: '2',
        type: 'price',
        title: 'Price Alert: TSLA',
        description: 'TSLA reached your target price of $250.00',
        timestamp: new Date(Date.now() - 15 * 60 * 1000),
        isRead: false,
        symbol: 'TSLA',
      },
      {
        id: '3',
        type: 'signal',
        title: 'SELL Signal: GOOGL',
        description: 'Technical analysis indicates SELL opportunity. Confidence: 72%',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        isRead: true,
        action: 'SELL',
        symbol: 'GOOGL',
      },
      {
        id: '4',
        type: 'news',
        title: 'Market News',
        description: 'Federal Reserve announces interest rate decision',
        timestamp: new Date(Date.now() - 60 * 60 * 1000),
        isRead: true,
      },
      {
        id: '5',
        type: 'price',
        title: 'Price Alert: NVDA',
        description: 'NVDA dropped below $400.00 support level',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        isRead: true,
        symbol: 'NVDA',
      },
    ];
    setAlerts(mockAlerts);
  };

  const markAsRead = (id: string) => {
    setAlerts(prev =>
      prev.map(alert =>
        alert.id === id ? { ...alert, isRead: true } : alert
      )
    );
  };

  const deleteAlert = (id: string) => {
    Alert.alert(
      'Delete Alert',
      'Are you sure you want to delete this alert?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setAlerts(prev => prev.filter(alert => alert.id !== id));
          },
        },
      ]
    );
  };

  const clearAllAlerts = () => {
    Alert.alert(
      'Clear All Alerts',
      'Are you sure you want to clear all alerts?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: () => setAlerts([]),
        },
      ]
    );
  };

  const sendTestNotification = async () => {
    try {
      await PushNotificationService.sendTradingSignalNotification({
        id: 'test',
        symbol: 'TEST',
        action: 'BUY',
        entry_price: 100.00,
        take_profit: 105.00,
        stop_loss: 98.00,
        confidence: 0.85,
        reasoning: 'This is a test notification',
        strategy_used: 'Test Strategy',
        risk_reward_ratio: 2.5,
        timeframe: '15m',
        timestamp: new Date(),
        status: 'ACTIVE',
      });
      Alert.alert('Test Sent', 'Test notification sent successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to send test notification');
    }
  };

  const getAlertIcon = (type: string, action?: string) => {
    switch (type) {
      case 'signal':
        return action === 'BUY' ? 
          <TrendingUp size={20} color={Colors.success} /> :
          <TrendingDown size={20} color={Colors.danger} />;
      case 'price':
        return <Bell size={20} color={Colors.warning} />;
      case 'news':
        return <Bell size={20} color={Colors.primary} />;
      default:
        return <Bell size={20} color={Colors.textMuted} />;
    }
  };

  const getTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (minutes < 60) {
      return `${minutes}m ago`;
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const renderAlert = (alert: AlertItem) => {
    return (
      <TouchableOpacity
        key={alert.id}
        style={[styles.alertItem, !alert.isRead && styles.unreadAlert]}
        onPress={() => markAsRead(alert.id)}
        onLongPress={() => deleteAlert(alert.id)}
      >
        <View style={styles.alertIcon}>
          {getAlertIcon(alert.type, alert.action)}
        </View>
        
        <View style={styles.alertContent}>
          <View style={styles.alertHeader}>
            <Text style={[styles.alertTitle, !alert.isRead && styles.unreadTitle]}>
              {alert.title}
            </Text>
            <Text style={styles.alertTime}>{getTimestamp(alert.timestamp)}</Text>
          </View>
          <Text style={styles.alertDescription} numberOfLines={2}>
            {alert.description}
          </Text>
        </View>
        
        {!alert.isRead && <View style={styles.unreadIndicator} />}
      </TouchableOpacity>
    );
  };

  const unreadCount = alerts.filter(alert => !alert.isRead).length;

  return (
    <LinearGradient colors={[Colors.background, Colors.backgroundLight]} style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>Alerts</Text>
          {unreadCount > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{unreadCount}</Text>
            </View>
          )}
        </View>
        <Text style={styles.subtitle}>Stay updated with market movements</Text>
      </View>

      <View style={styles.settingsSection}>
        <Text style={styles.settingsTitle}>Notification Settings</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Bell size={20} color={Colors.primary} />
            <Text style={styles.settingLabel}>Push Notifications</Text>
          </View>
          <Switch
            value={notificationsEnabled}
            onValueChange={setNotificationsEnabled}
            trackColor={{ false: Colors.surface, true: Colors.primary }}
            thumbColor={Colors.textPrimary}
          />
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            {soundEnabled ? 
              <Volume2 size={20} color={Colors.primary} /> :
              <VolumeX size={20} color={Colors.textMuted} />
            }
            <Text style={styles.settingLabel}>Sound</Text>
          </View>
          <Switch
            value={soundEnabled}
            onValueChange={setSoundEnabled}
            trackColor={{ false: Colors.surface, true: Colors.primary }}
            thumbColor={Colors.textPrimary}
          />
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <TrendingUp size={20} color={Colors.success} />
            <Text style={styles.settingLabel}>Trading Signals</Text>
          </View>
          <Switch
            value={signalAlertsEnabled}
            onValueChange={setSignalAlertsEnabled}
            trackColor={{ false: Colors.surface, true: Colors.primary }}
            thumbColor={Colors.textPrimary}
          />
        </View>

        <View style={styles.settingItem}>
          <View style={styles.settingLeft}>
            <Settings size={20} color={Colors.warning} />
            <Text style={styles.settingLabel}>Price Alerts</Text>
          </View>
          <Switch
            value={priceAlertsEnabled}
            onValueChange={setPriceAlertsEnabled}
            trackColor={{ false: Colors.surface, true: Colors.primary }}
            thumbColor={Colors.textPrimary}
          />
        </View>

        <TouchableOpacity style={styles.testButton} onPress={sendTestNotification}>
          <Text style={styles.testButtonText}>Send Test Notification</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.alertsHeader}>
        <Text style={styles.alertsTitle}>Recent Alerts</Text>
        {alerts.length > 0 && (
          <TouchableOpacity onPress={clearAllAlerts}>
            <Text style={styles.clearAllText}>Clear All</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.alertsList} showsVerticalScrollIndicator={false}>
        {alerts.length > 0 ? (
          alerts.map(renderAlert)
        ) : (
          <View style={styles.emptyContainer}>
            <Bell size={50} color={Colors.textMuted} />
            <Text style={styles.emptyText}>No alerts yet</Text>
            <Text style={styles.emptySubtext}>You'll see notifications here when they arrive</Text>
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: FontSizes.xxxl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginRight: Spacing.sm,
  },
  badge: {
    backgroundColor: Colors.danger,
    borderRadius: BorderRadius.full,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    minWidth: 24,
    alignItems: 'center',
  },
  badgeText: {
    fontSize: FontSizes.xs,
    color: Colors.textPrimary,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  settingsSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  settingsTitle: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.cardBackground,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    marginBottom: Spacing.sm,
    borderRadius: BorderRadius.lg,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  settingLabel: {
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    fontWeight: '500',
  },
  testButton: {
    backgroundColor: Colors.primary,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  testButtonText: {
    fontSize: FontSizes.md,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  alertsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  alertsTitle: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  clearAllText: {
    fontSize: FontSizes.md,
    color: Colors.danger,
    fontWeight: '500',
  },
  alertsList: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  alertItem: {
    flexDirection: 'row',
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    borderLeftWidth: 4,
    borderLeftColor: Colors.border,
  },
  unreadAlert: {
    borderLeftColor: Colors.primary,
    backgroundColor: 'rgba(59, 130, 246, 0.05)',
  },
  alertIcon: {
    marginRight: Spacing.md,
    paddingTop: 2,
  },
  alertContent: {
    flex: 1,
  },
  alertHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.xs,
  },
  alertTitle: {
    fontSize: FontSizes.md,
    fontWeight: '600',
    color: Colors.textPrimary,
    flex: 1,
    marginRight: Spacing.sm,
  },
  unreadTitle: {
    color: Colors.primary,
  },
  alertTime: {
    fontSize: FontSizes.xs,
    color: Colors.textMuted,
  },
  alertDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 18,
  },
  unreadIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
    marginLeft: Spacing.sm,
    marginTop: 4,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: FontSizes.lg,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginTop: Spacing.md,
  },
  emptySubtext: {
    fontSize: FontSizes.md,
    color: Colors.textMuted,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
});