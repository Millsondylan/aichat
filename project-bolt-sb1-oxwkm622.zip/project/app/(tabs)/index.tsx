import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TrendingUp, TrendingDown, DollarSign, Brain, Zap } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius, FontSizes } from '@/constants/colors';
import { TradingSignal } from '@/types/trading';
import { SignalGenerator } from '@/services/trading/signalGenerator';
import { PolygonService } from '@/services/market/polygon';
import { YahooFinanceService } from '@/services/market/yahoo';
import { PushNotificationService } from '@/services/notifications/pushNotifications';

export default function SignalsScreen() {
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [activeSignals, setActiveSignals] = useState(0);
  const [dailyPnL, setDailyPnL] = useState(0);

  const signalGenerator = new SignalGenerator();
  const polygonService = new PolygonService();
  const yahooService = new YahooFinanceService();

  const popularSymbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'META', 'AMZN', 'NFLX'];

  useEffect(() => {
    initializeApp();
    generateInitialSignals();
  }, []);

  const initializeApp = async () => {
    await PushNotificationService.requestPermissions();
    await PushNotificationService.setupNotificationCategories();
  };

  const generateInitialSignals = async () => {
    setLoading(true);
    try {
      const newSignals: TradingSignal[] = [];
      
      // Generate signals for popular symbols
      for (const symbol of popularSymbols.slice(0, 4)) {
        try {
          const marketData = await yahooService.getQuote(symbol);
          const historicalData = await yahooService.getHistoricalData(symbol, '5d');
          
          const signal = await signalGenerator.generateComprehensiveSignal(
            symbol,
            { ...marketData, historical: historicalData }
          );
          
          if (signal) {
            newSignals.push(signal);
          }
        } catch (error) {
          console.error(`Error generating signal for ${symbol}:`, error);
        }
      }

      setSignals(newSignals);
      setActiveSignals(newSignals.filter(s => s.status === 'ACTIVE').length);
      
      // Send notifications for high-confidence signals
      newSignals.forEach(signal => {
        if (signal.confidence > 0.7) {
          PushNotificationService.sendTradingSignalNotification(signal);
        }
      });
      
    } catch (error) {
      console.error('Error generating initial signals:', error);
      Alert.alert('Error', 'Failed to generate trading signals. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await generateInitialSignals();
    setRefreshing(false);
  };

  const generateNewSignal = async () => {
    setLoading(true);
    try {
      const randomSymbol = popularSymbols[Math.floor(Math.random() * popularSymbols.length)];
      const marketData = await yahooService.getQuote(randomSymbol);
      const historicalData = await yahooService.getHistoricalData(randomSymbol, '5d');
      
      const signal = await signalGenerator.generateComprehensiveSignal(
        randomSymbol,
        { ...marketData, historical: historicalData }
      );
      
      if (signal) {
        setSignals(prev => [signal, ...prev]);
        setActiveSignals(prev => prev + 1);
        await PushNotificationService.sendTradingSignalNotification(signal);
        Alert.alert('New Signal Generated!', `${signal.action} signal for ${signal.symbol} with ${Math.round(signal.confidence * 100)}% confidence.`);
      } else {
        Alert.alert('No Signal', 'Market conditions do not meet signal criteria at this time.');
      }
    } catch (error) {
      console.error('Error generating new signal:', error);
      Alert.alert('Error', 'Failed to generate signal. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const renderSignalCard = (signal: TradingSignal) => {
    const isProfit = signal.action === 'BUY' ? 
      (signal.take_profit > signal.entry_price) : 
      (signal.entry_price > signal.take_profit);
    
    const signalColor = signal.action === 'BUY' ? Colors.success : Colors.danger;
    const confidenceColor = signal.confidence > 0.7 ? Colors.success : 
                           signal.confidence > 0.5 ? Colors.warning : Colors.textMuted;

    return (
      <View key={signal.id} style={[styles.signalCard, { borderLeftColor: signalColor }]}>
        <View style={styles.signalHeader}>
          <View style={styles.symbolContainer}>
            <Text style={styles.symbol}>{signal.symbol}</Text>
            <View style={[styles.actionBadge, { backgroundColor: signalColor }]}>
              <Text style={styles.actionText}>{signal.action}</Text>
              {signal.action === 'BUY' ? 
                <TrendingUp size={14} color={Colors.textPrimary} /> :
                <TrendingDown size={14} color={Colors.textPrimary} />
              }
            </View>
          </View>
          <View style={styles.confidenceContainer}>
            <Text style={[styles.confidence, { color: confidenceColor }]}>
              {Math.round(signal.confidence * 100)}%
            </Text>
            <Text style={styles.strategy}>{signal.strategy_used}</Text>
          </View>
        </View>

        <View style={styles.priceContainer}>
          <View style={styles.priceItem}>
            <Text style={styles.priceLabel}>Entry</Text>
            <Text style={styles.priceValue}>${signal.entry_price.toFixed(2)}</Text>
          </View>
          <View style={styles.priceItem}>
            <Text style={styles.priceLabel}>Take Profit</Text>
            <Text style={[styles.priceValue, { color: Colors.success }]}>
              ${signal.take_profit.toFixed(2)}
            </Text>
          </View>
          <View style={styles.priceItem}>
            <Text style={styles.priceLabel}>Stop Loss</Text>
            <Text style={[styles.priceValue, { color: Colors.danger }]}>
              ${signal.stop_loss.toFixed(2)}
            </Text>
          </View>
        </View>

        <View style={styles.signalFooter}>
          <View style={styles.riskReward}>
            <Text style={styles.riskLabel}>Risk/Reward: </Text>
            <Text style={styles.riskValue}>{signal.risk_reward_ratio.toFixed(2)}</Text>
          </View>
          <Text style={styles.timeframe}>{signal.timeframe}</Text>
        </View>

        <Text style={styles.reasoning} numberOfLines={2}>
          {signal.reasoning}
        </Text>
      </View>
    );
  };

  return (
    <LinearGradient colors={[Colors.background, Colors.backgroundLight]} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>TradeMaster AI</Text>
        <Text style={styles.subtitle}>AI-Powered Trading Signals</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <Brain size={20} color={Colors.primary} />
          </View>
          <Text style={styles.statValue}>{activeSignals}</Text>
          <Text style={styles.statLabel}>Active Signals</Text>
        </View>
        
        <View style={styles.statCard}>
          <View style={styles.statIconContainer}>
            <DollarSign size={20} color={dailyPnL >= 0 ? Colors.success : Colors.danger} />
          </View>
          <Text style={[styles.statValue, { color: dailyPnL >= 0 ? Colors.success : Colors.danger }]}>
            ${Math.abs(dailyPnL).toFixed(2)}
          </Text>
          <Text style={styles.statLabel}>Daily P&L</Text>
        </View>
        
        <TouchableOpacity 
          style={[styles.statCard, styles.generateButton]} 
          onPress={generateNewSignal}
          disabled={loading}
        >
          <View style={styles.statIconContainer}>
            <Zap size={20} color={Colors.warning} />
          </View>
          <Text style={[styles.statValue, { color: Colors.warning }]}>New</Text>
          <Text style={styles.statLabel}>Generate</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.signalsContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.primary}
            colors={[Colors.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {loading && signals.length === 0 ? (
          <View style={styles.loadingContainer}>
            <Brain size={40} color={Colors.primary} />
            <Text style={styles.loadingText}>Generating AI Signals...</Text>
            <Text style={styles.loadingSubtext}>Analyzing market conditions</Text>
          </View>
        ) : signals.length > 0 ? (
          signals.map(renderSignalCard)
        ) : (
          <View style={styles.emptyContainer}>
            <TrendingUp size={50} color={Colors.textMuted} />
            <Text style={styles.emptyText}>No signals available</Text>
            <Text style={styles.emptySubtext}>Pull down to refresh or generate new signals</Text>
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
    alignItems: 'center',
  },
  title: {
    fontSize: FontSizes.xxxl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
    gap: Spacing.md,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.cardBackground,
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  generateButton: {
    borderColor: Colors.warning,
    borderWidth: 1,
  },
  statIconContainer: {
    marginBottom: Spacing.xs,
  },
  statValue: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  statLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
  },
  signalsContainer: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  signalCard: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    borderLeftWidth: 4,
    borderColor: Colors.border,
  },
  signalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.md,
  },
  symbolContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  symbol: {
    fontSize: FontSizes.xl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  actionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
    gap: 4,
  },
  actionText: {
    fontSize: FontSizes.sm,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  confidenceContainer: {
    alignItems: 'flex-end',
  },
  confidence: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  strategy: {
    fontSize: FontSizes.xs,
    color: Colors.textMuted,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  priceItem: {
    alignItems: 'center',
  },
  priceLabel: {
    fontSize: FontSizes.xs,
    color: Colors.textMuted,
    marginBottom: 2,
  },
  priceValue: {
    fontSize: FontSizes.md,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  signalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  riskReward: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  riskLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
  },
  riskValue: {
    fontSize: FontSizes.sm,
    fontWeight: '600',
    color: Colors.primary,
  },
  timeframe: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
    fontWeight: '500',
  },
  reasoning: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 18,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  loadingText: {
    fontSize: FontSizes.lg,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginTop: Spacing.md,
  },
  loadingSubtext: {
    fontSize: FontSizes.md,
    color: Colors.textMuted,
    marginTop: Spacing.xs,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: FontSizes.lg,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginTop: Spacing.md,
  },
  emptySubtext: {
    fontSize: FontSizes.md,
    color: Colors.textMuted,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
});