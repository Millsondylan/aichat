import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Search, TrendingUp, TrendingDown, Activity, DollarSign } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius, FontSizes } from '@/constants/colors';
import { MarketData } from '@/types/trading';
import { YahooFinanceService } from '@/services/market/yahoo';
import { PolygonService } from '@/services/market/polygon';

export default function MarketScreen() {
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [topGainers, setTopGainers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const yahooService = new YahooFinanceService();
  const polygonService = new PolygonService();

  const watchedSymbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'META', 'AMZN', 'SPY'];

  useEffect(() => {
    loadMarketData();
  }, []);

  const loadMarketData = async () => {
    setLoading(true);
    try {
      // Load market data for watched symbols
      const marketPromises = watchedSymbols.map(symbol => 
        yahooService.getQuote(symbol).catch(error => {
          console.error(`Error loading ${symbol}:`, error);
          return null;
        })
      );

      const marketResults = await Promise.all(marketPromises);
      const validMarketData = marketResults.filter(data => data !== null) as MarketData[];
      setMarketData(validMarketData);

      // Load top gainers
      try {
        const gainers = await polygonService.getTopGainers();
        setTopGainers(gainers);
      } catch (error) {
        console.error('Error loading top gainers:', error);
      }
    } catch (error) {
      console.error('Error loading market data:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadMarketData();
    setRefreshing(false);
  };

  const searchSymbols = async (query: string) => {
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }

    try {
      const results = await yahooService.searchSymbols(query);
      setSearchResults(results.slice(0, 8));
    } catch (error) {
      console.error('Error searching symbols:', error);
      setSearchResults([]);
    }
  };

  const renderMarketItem = (item: MarketData) => {
    const isPositive = item.change >= 0;
    const changeColor = isPositive ? Colors.success : Colors.danger;
    const TrendIcon = isPositive ? TrendingUp : TrendingDown;

    return (
      <TouchableOpacity key={item.symbol} style={styles.marketItem}>
        <View style={styles.marketItemLeft}>
          <Text style={styles.marketSymbol}>{item.symbol}</Text>
          <Text style={styles.marketPrice}>${item.price.toFixed(2)}</Text>
        </View>
        
        <View style={styles.marketItemRight}>
          <View style={styles.changeContainer}>
            <TrendIcon size={16} color={changeColor} />
            <Text style={[styles.changeText, { color: changeColor }]}>
              {isPositive ? '+' : ''}{item.change_percent.toFixed(2)}%
            </Text>
          </View>
          <Text style={styles.changeValue}>
            {isPositive ? '+' : ''}${item.change.toFixed(2)}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const renderGainerItem = (item: any, index: number) => {
    return (
      <TouchableOpacity key={item.symbol} style={styles.gainerItem}>
        <View style={styles.gainerRank}>
          <Text style={styles.rankText}>#{index + 1}</Text>
        </View>
        <View style={styles.gainerInfo}>
          <Text style={styles.gainerSymbol}>{item.symbol}</Text>
          <Text style={styles.gainerPrice}>${item.price?.toFixed(2) || 'N/A'}</Text>
        </View>
        <View style={styles.gainerChange}>
          <Text style={[styles.gainerChangeText, { color: Colors.success }]}>
            +{item.change?.toFixed(2) || '0.00'}%
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const renderSearchItem = (item: any) => {
    return (
      <TouchableOpacity key={item.symbol} style={styles.searchItem}>
        <View>
          <Text style={styles.searchSymbol}>{item.symbol}</Text>
          <Text style={styles.searchName} numberOfLines={1}>{item.name}</Text>
        </View>
        <View>
          <Text style={styles.searchExchange}>{item.exchange}</Text>
          <Text style={styles.searchType}>{item.type}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <LinearGradient colors={[Colors.background, Colors.backgroundLight]} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Market Overview</Text>
        <View style={styles.searchContainer}>
          <Search size={20} color={Colors.textMuted} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search symbols..."
            placeholderTextColor={Colors.textMuted}
            value={searchQuery}
            onChangeText={(text) => {
              setSearchQuery(text);
              searchSymbols(text);
            }}
          />
        </View>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.primary}
            colors={[Colors.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {searchResults.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Search Results</Text>
            <View style={styles.searchResults}>
              {searchResults.map(renderSearchItem)}
            </View>
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Activity size={20} color={Colors.primary} />
            <Text style={styles.sectionTitle}>Watchlist</Text>
          </View>
          
          <View style={styles.marketList}>
            {marketData.map(renderMarketItem)}
          </View>
        </View>

        {topGainers.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <TrendingUp size={20} color={Colors.success} />
              <Text style={styles.sectionTitle}>Top Gainers</Text>
            </View>
            
            <View style={styles.gainersList}>
              {topGainers.slice(0, 5).map(renderGainerItem)}
            </View>
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <DollarSign size={20} color={Colors.warning} />
            <Text style={styles.sectionTitle}>Market Stats</Text>
          </View>
          
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Total Volume</Text>
              <Text style={styles.statValue}>2.4B</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Market Cap</Text>
              <Text style={styles.statValue}>$45.2T</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Active Stocks</Text>
              <Text style={styles.statValue}>8,429</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Fear & Greed</Text>
              <Text style={[styles.statValue, { color: Colors.warning }]}>65</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
  },
  title: {
    fontSize: FontSizes.xxxl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: Spacing.lg,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.inputBackground,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    height: 48,
  },
  searchIcon: {
    marginRight: Spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.md,
    gap: Spacing.sm,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  searchResults: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
    padding: Spacing.sm,
  },
  searchItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  searchSymbol: {
    fontSize: FontSizes.md,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  searchName: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  searchExchange: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
    textAlign: 'right',
  },
  searchType: {
    fontSize: FontSizes.xs,
    color: Colors.textMuted,
    textAlign: 'right',
    marginTop: 2,
  },
  marketList: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
  },
  marketItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  marketItemLeft: {
    flex: 1,
  },
  marketSymbol: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  marketPrice: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  marketItemRight: {
    alignItems: 'flex-end',
  },
  changeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 2,
  },
  changeText: {
    fontSize: FontSizes.md,
    fontWeight: '600',
  },
  changeValue: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
  },
  gainersList: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
  },
  gainerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  gainerRank: {
    width: 30,
    marginRight: Spacing.md,
  },
  rankText: {
    fontSize: FontSizes.sm,
    fontWeight: 'bold',
    color: Colors.warning,
  },
  gainerInfo: {
    flex: 1,
  },
  gainerSymbol: {
    fontSize: FontSizes.md,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  gainerPrice: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  gainerChange: {
    alignItems: 'flex-end',
  },
  gainerChangeText: {
    fontSize: FontSizes.md,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  statItem: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: Colors.cardBackground,
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
  },
  statLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
    marginBottom: Spacing.xs,
  },
  statValue: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
});