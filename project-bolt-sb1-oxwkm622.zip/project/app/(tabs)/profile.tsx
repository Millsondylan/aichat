import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { User, Settings, CreditCard, LogOut, Moon, Sun, Shield, Circle as HelpCircle, Star, TrendingUp, DollarSign } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius, FontSizes } from '@/constants/colors';
import { supabase, signOut, getCurrentUser } from '@/services/supabase';

export default function ProfileScreen() {
  const [user, setUser] = useState<any>(null);
  const [darkMode, setDarkMode] = useState(true);
  const [autoTrading, setAutoTrading] = useState(false);
  const [highRiskTolerance, setHighRiskTolerance] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [stats, setStats] = useState({
    totalSignals: 127,
    successRate: 73.4,
    totalProfit: 2847.50,
    activeTrades: 5,
  });

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const { user, error } = await getCurrentUser();
      if (error) {
        console.error('Error loading user:', error);
      } else {
        setUser(user);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await signOut();
              if (error) {
                Alert.alert('Error', 'Failed to sign out');
              }
            } catch (error) {
              Alert.alert('Error', 'Failed to sign out');
            }
          },
        },
      ]
    );
  };

  const handleUpgradeToPremium = () => {
    Alert.alert(
      'Upgrade to Premium',
      'Get unlimited AI signals, advanced analytics, and priority support for $40',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Upgrade', onPress: () => {
          Alert.alert('Coming Soon', 'PayPal integration will be available in the next update!');
        }},
      ]
    );
  };

  const renderSettingItem = (
    icon: React.ReactNode,
    title: string,
    subtitle?: string,
    onPress?: () => void,
    rightElement?: React.ReactNode,
    showChevron: boolean = true
  ) => {
    return (
      <TouchableOpacity 
        style={styles.settingItem} 
        onPress={onPress}
        disabled={!onPress && !rightElement}
      >
        <View style={styles.settingLeft}>
          <View style={styles.settingIcon}>{icon}</View>
          <View style={styles.settingText}>
            <Text style={styles.settingTitle}>{title}</Text>
            {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
          </View>
        </View>
        {rightElement || (showChevron && onPress && (
          <Text style={styles.chevron}>›</Text>
        ))}
      </TouchableOpacity>
    );
  };

  const renderStatCard = (icon: React.ReactNode, value: string, label: string, color: string) => {
    return (
      <View style={styles.statCard}>
        <View style={[styles.statIcon, { backgroundColor: color }]}>
          {icon}
        </View>
        <Text style={styles.statValue}>{value}</Text>
        <Text style={styles.statLabel}>{label}</Text>
      </View>
    );
  };

  return (
    <LinearGradient colors={[Colors.background, Colors.backgroundLight]} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.profileSection}>
            <View style={styles.avatar}>
              <User size={40} color={Colors.textPrimary} />
            </View>
            <View style={styles.userInfo}>
              <Text style={styles.userName}>
                {user?.email?.split('@')[0] || 'Trader'}
              </Text>
              <Text style={styles.userEmail}>{user?.email || 'trader@example.com'}</Text>
              {isPremium ? (
                <View style={styles.premiumBadge}>
                  <Star size={12} color={Colors.warning} />
                  <Text style={styles.premiumText}>Premium</Text>
                </View>
              ) : (
                <TouchableOpacity style={styles.upgradeButton} onPress={handleUpgradeToPremium}>
                  <Text style={styles.upgradeText}>Upgrade to Premium</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>

        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Trading Performance</Text>
          <View style={styles.statsGrid}>
            {renderStatCard(
              <TrendingUp size={20} color={Colors.textPrimary} />,
              stats.totalSignals.toString(),
              'Total Signals',
              Colors.primary
            )}
            {renderStatCard(
              <Star size={20} color={Colors.textPrimary} />,
              `${stats.successRate}%`,
              'Success Rate',
              Colors.success
            )}
            {renderStatCard(
              <DollarSign size={20} color={Colors.textPrimary} />,
              `$${stats.totalProfit.toFixed(0)}`,
              'Total Profit',
              Colors.warning
            )}
            {renderStatCard(
              <Settings size={20} color={Colors.textPrimary} />,
              stats.activeTrades.toString(),
              'Active Trades',
              Colors.accent
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Trading Preferences</Text>
          
          {renderSettingItem(
            <Settings size={20} color={Colors.primary} />,
            'Auto Trading',
            'Automatically execute signals',
            undefined,
            <Switch
              value={autoTrading}
              onValueChange={setAutoTrading}
              trackColor={{ false: Colors.surface, true: Colors.primary }}
              thumbColor={Colors.textPrimary}
            />,
            false
          )}
          
          {renderSettingItem(
            <Shield size={20} color={Colors.warning} />,
            'High Risk Tolerance',
            'Accept higher risk/reward signals',
            undefined,
            <Switch
              value={highRiskTolerance}
              onValueChange={setHighRiskTolerance}
              trackColor={{ false: Colors.surface, true: Colors.warning }}
              thumbColor={Colors.textPrimary}
            />,
            false
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>App Settings</Text>
          
          {renderSettingItem(
            darkMode ? <Moon size={20} color={Colors.primary} /> : <Sun size={20} color={Colors.warning} />,
            'Dark Mode',
            'Toggle app appearance',
            undefined,
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              trackColor={{ false: Colors.surface, true: Colors.primary }}
              thumbColor={Colors.textPrimary}
            />,
            false
          )}
          
          {renderSettingItem(
            <CreditCard size={20} color={Colors.success} />,
            'Payment & Billing',
            'Manage subscription and payments',
            () => Alert.alert('Payment Settings', 'Manage your subscription and payment methods')
          )}
          
          {renderSettingItem(
            <Shield size={20} color={Colors.primary} />,
            'Privacy & Security',
            'Account security and data privacy',
            () => Alert.alert('Privacy Settings', 'Manage your privacy and security settings')
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          
          {renderSettingItem(
            <HelpCircle size={20} color={Colors.primary} />,
            'Help & Support',
            'Get help and contact support',
            () => Alert.alert('Help', 'Contact support at support@trademaster.ai')
          )}
          
          {renderSettingItem(
            <Star size={20} color={Colors.warning} />,
            'Rate TradeMaster AI',
            'Share your experience',
            () => Alert.alert('Rate App', 'Thank you for using TradeMaster AI!')
          )}
        </View>

        <View style={styles.section}>
          {renderSettingItem(
            <LogOut size={20} color={Colors.danger} />,
            'Sign Out',
            'Sign out of your account',
            handleSignOut
          )}
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>TradeMaster AI v1.0.0</Text>
          <Text style={styles.footerSubtext}>Built for professional traders</Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.lg,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: Colors.primary,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: FontSizes.xl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.warning,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    alignSelf: 'flex-start',
    gap: 4,
  },
  premiumText: {
    fontSize: FontSizes.sm,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  upgradeButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.md,
    alignSelf: 'flex-start',
  },
  upgradeText: {
    fontSize: FontSizes.sm,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  statsSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: Colors.cardBackground,
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  statValue: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  statLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.cardBackground,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    marginBottom: Spacing.sm,
    borderRadius: BorderRadius.lg,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: Spacing.md,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: FontSizes.md,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  chevron: {
    fontSize: 20,
    color: Colors.textMuted,
    fontWeight: '300',
  },
  footer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
  footerText: {
    fontSize: FontSizes.sm,
    color: Colors.textMuted,
    marginBottom: 4,
  },
  footerSubtext: {
    fontSize: FontSizes.xs,
    color: Colors.textMuted,
  },
});