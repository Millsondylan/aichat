import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Plus, Trash2, TrendingUp, TrendingDown, Bell } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius, FontSizes } from '@/constants/colors';
import { WatchlistItem } from '@/types/trading';
import { YahooFinanceService } from '@/services/market/yahoo';

export default function WatchlistScreen() {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [newSymbol, setNewSymbol] = useState('');
  const [loading, setLoading] = useState(false);

  const yahooService = new YahooFinanceService();

  useEffect(() => {
    loadDefaultWatchlist();
  }, []);

  const loadDefaultWatchlist = async () => {
    setLoading(true);
    const defaultSymbols = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA'];
    
    try {
      const watchlistPromises = defaultSymbols.map(async (symbol) => {
        try {
          const quote = await yahooService.getQuote(symbol);
          return {
            id: `${symbol}_${Date.now()}`,
            symbol: quote.symbol,
            name: symbol,
            price: quote.price,
            change: quote.change,
            change_percent: quote.change_percent,
            created_at: new Date(),
          };
        } catch (error) {
          console.error(`Error loading ${symbol}:`, error);
          return null;
        }
      });

      const results = await Promise.all(watchlistPromises);
      const validItems = results.filter(item => item !== null) as WatchlistItem[];
      setWatchlist(validItems);
    } catch (error) {
      console.error('Error loading default watchlist:', error);
    } finally {
      setLoading(false);
    }
  };

  const addToWatchlist = async () => {
    if (!newSymbol.trim()) {
      Alert.alert('Error', 'Please enter a symbol');
      return;
    }

    const symbol = newSymbol.toUpperCase().trim();
    
    // Check if already in watchlist
    if (watchlist.some(item => item.symbol === symbol)) {
      Alert.alert('Error', 'Symbol already in watchlist');
      return;
    }

    setLoading(true);
    try {
      const quote = await yahooService.getQuote(symbol);
      
      const newItem: WatchlistItem = {
        id: `${symbol}_${Date.now()}`,
        symbol: quote.symbol,
        name: symbol,
        price: quote.price,
        change: quote.change,
        change_percent: quote.change_percent,
        created_at: new Date(),
      };

      setWatchlist(prev => [newItem, ...prev]);
      setNewSymbol('');
      Alert.alert('Success', `${symbol} added to watchlist`);
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      Alert.alert('Error', 'Failed to add symbol. Please check the symbol and try again.');
    } finally {
      setLoading(false);
    }
  };

  const removeFromWatchlist = (id: string) => {
    Alert.alert(
      'Remove from Watchlist',
      'Are you sure you want to remove this item?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            setWatchlist(prev => prev.filter(item => item.id !== id));
          },
        },
      ]
    );
  };

  const setPriceAlert = (item: WatchlistItem) => {
    Alert.prompt(
      'Set Price Alert',
      `Set alert for ${item.symbol} (Current: $${item.price.toFixed(2)})`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Set Alert',
          onPress: (alertPrice) => {
            const price = parseFloat(alertPrice || '0');
            if (price > 0) {
              setWatchlist(prev =>
                prev.map(watchlistItem =>
                  watchlistItem.id === item.id
                    ? { ...watchlistItem, alert_price: price }
                    : watchlistItem
                )
              );
              Alert.alert('Alert Set', `Alert set for ${item.symbol} at $${price.toFixed(2)}`);
            }
          },
        },
      ],
      'plain-text',
      item.price.toFixed(2)
    );
  };

  const renderWatchlistItem = (item: WatchlistItem) => {
    const isPositive = item.change >= 0;
    const changeColor = isPositive ? Colors.success : Colors.danger;
    const TrendIcon = isPositive ? TrendingUp : TrendingDown;

    return (
      <View key={item.id} style={styles.watchlistItem}>
        <TouchableOpacity
          style={styles.itemContent}
          onLongPress={() => removeFromWatchlist(item.id)}
        >
          <View style={styles.itemLeft}>
            <Text style={styles.itemSymbol}>{item.symbol}</Text>
            <Text style={styles.itemName}>{item.name}</Text>
            {item.alert_price && (
              <View style={styles.alertBadge}>
                <Bell size={12} color={Colors.warning} />
                <Text style={styles.alertText}>${item.alert_price.toFixed(2)}</Text>
              </View>
            )}
          </View>

          <View style={styles.itemCenter}>
            <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
          </View>

          <View style={styles.itemRight}>
            <View style={styles.changeContainer}>
              <TrendIcon size={16} color={changeColor} />
              <Text style={[styles.changePercent, { color: changeColor }]}>
                {isPositive ? '+' : ''}{item.change_percent.toFixed(2)}%
              </Text>
            </View>
            <Text style={[styles.changeValue, { color: changeColor }]}>
              {isPositive ? '+' : ''}${item.change.toFixed(2)}
            </Text>
          </View>
        </TouchableOpacity>

        <View style={styles.itemActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => setPriceAlert(item)}
          >
            <Bell size={16} color={Colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, styles.deleteButton]}
            onPress={() => removeFromWatchlist(item.id)}
          >
            <Trash2 size={16} color={Colors.danger} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <LinearGradient colors={[Colors.background, Colors.backgroundLight]} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Watchlist</Text>
        <Text style={styles.subtitle}>Track your favorite symbols</Text>
      </View>

      <View style={styles.addSection}>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Enter symbol (e.g., AAPL)"
            placeholderTextColor={Colors.textMuted}
            value={newSymbol}
            onChangeText={setNewSymbol}
            autoCapitalize="characters"
            autoCorrect={false}
          />
          <TouchableOpacity
            style={styles.addButton}
            onPress={addToWatchlist}
            disabled={loading}
          >
            <Plus size={20} color={Colors.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.watchlistContainer} showsVerticalScrollIndicator={false}>
        {watchlist.length > 0 ? (
          watchlist.map(renderWatchlistItem)
        ) : (
          <View style={styles.emptyContainer}>
            <TrendingUp size={50} color={Colors.textMuted} />
            <Text style={styles.emptyText}>Your watchlist is empty</Text>
            <Text style={styles.emptySubtext}>Add symbols to track their performance</Text>
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.lg,
  },
  title: {
    fontSize: FontSizes.xxxl,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  addSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  inputContainer: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    backgroundColor: Colors.inputBackground,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  addButton: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
    width: 48,
  },
  watchlistContainer: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
  },
  watchlistItem: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.md,
    overflow: 'hidden',
  },
  itemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  itemLeft: {
    flex: 2,
  },
  itemSymbol: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  itemName: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  alertBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.warning,
    paddingHorizontal: Spacing.xs,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
    alignSelf: 'flex-start',
    gap: 4,
  },
  alertText: {
    fontSize: FontSizes.xs,
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  itemCenter: {
    flex: 1,
    alignItems: 'center',
  },
  itemPrice: {
    fontSize: FontSizes.lg,
    fontWeight: 'bold',
    color: Colors.textPrimary,
  },
  itemRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  changeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 2,
  },
  changePercent: {
    fontSize: FontSizes.md,
    fontWeight: '600',
  },
  changeValue: {
    fontSize: FontSizes.sm,
  },
  itemActions: {
    flexDirection: 'row',
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
  },
  actionButton: {
    backgroundColor: Colors.cardBackground,
    borderRadius: BorderRadius.md,
    padding: Spacing.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: FontSizes.lg,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginTop: Spacing.md,
  },
  emptySubtext: {
    fontSize: FontSizes.md,
    color: Colors.textMuted,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
});