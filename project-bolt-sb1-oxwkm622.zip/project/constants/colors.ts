export const Colors = {
  // Primary colors
  primary: '#1E40AF',
  primaryDark: '#1E3A8A',
  primaryLight: '#3B82F6',
  
  // Success/Profit colors
  success: '#059669',
  successDark: '#047857',
  successLight: '#10B981',
  
  // Danger/Loss colors
  danger: '#DC2626',
  dangerDark: '#B91C1C',
  dangerLight: '#EF4444',
  
  // Warning colors
  warning: '#D97706',
  warningDark: '#B45309',
  warningLight: '#F59E0B',
  
  // Neutral colors
  background: '#0F172A',
  backgroundLight: '#1E293B',
  surface: '#334155',
  surfaceLight: '#475569',
  
  // Text colors
  textPrimary: '#F8FAFC',
  textSecondary: '#CBD5E1',
  textMuted: '#64748B',
  
  // Border colors
  border: '#334155',
  borderLight: '#475569',
  
  // Accent colors
  accent: '#8B5CF6',
  accentDark: '#7C3AED',
  accentLight: '#A78BFA',
  
  // Chart colors
  chartGreen: '#22C55E',
  chartRed: '#EF4444',
  chartBlue: '#3B82F6',
  chartYellow: '#EAB308',
  chartPurple: '#A855F7',
  chartOrange: '#F97316',
  
  // Transparency variants
  overlay: 'rgba(15, 23, 42, 0.8)',
  cardBackground: 'rgba(30, 41, 59, 0.95)',
  inputBackground: 'rgba(51, 65, 85, 0.5)',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const BorderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  xxl: 24,
  full: 9999,
};

export const FontSizes = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};